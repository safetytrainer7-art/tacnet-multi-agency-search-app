import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import "@/App.css";
import "leaflet/dist/leaflet.css";
import { AuthProvider, useAuth } from "@/lib/auth";
import HomePage from "@/components/HomePage";
import Dashboard from "@/components/Dashboard";
import CaseDetail from "@/components/CaseDetail";

function Protected({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <div className="tac-loading">LOADING TACNET…</div>;
  if (!user) return <Navigate to="/" replace />;
  return children;
}

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster position="top-right" theme="dark" richColors />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/dashboard" element={<Protected><Dashboard /></Protected>} />
          <Route path="/cases/:id" element={<Protected><CaseDetail /></Protected>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;
