import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, LogOut, MapPin, FileText, Users, AlertOctagon, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api, useAuth } from "@/lib/auth";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [cases, setCases] = useState([]);
  const [stats, setStats] = useState({active_cases: 0, closed_cases: 0, deployed_searchers: 0, active_alerts: 0});
  const [showCreate, setShowCreate] = useState(false);

  const load = useCallback(async () => {
    try {
      const [c, s] = await Promise.all([api.get("/cases"), api.get("/stats")]);
      setCases(c.data); setStats(s.data);
    } catch (e) {
      console.warn("[TACNET] dashboard load failed:", e);
      toast.error("Failed to load dashboard");
    }
  }, []);

  useEffect(() => {
    load();
    const i = setInterval(load, 8000);
    return () => clearInterval(i);
  }, [load]);

  const doLogout = async () => { await logout(); navigate("/"); };

  const deleteCase = async (e, caseId, caseTitle) => {
    e.stopPropagation();
    if (!confirm(`Delete case "${caseTitle}"?\n\nThis permanently removes the case and ALL its data (GPS positions, deployed searchers, drawings, audit log, tokens, alerts). This cannot be undone.`)) return;
    try {
      await api.delete(`/cases/${caseId}`);
      toast.success("Case deleted");
      load();
    } catch (err) {
      console.warn("[TACNET] delete case failed:", err);
      toast.error(err.response?.data?.detail || "Failed to delete case");
    }
  };

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="app-brand">
          TACNET
          <span className="creator-sub">Earl Wood · Dep. Sheriff (Ret.) · VA</span>
        </div>
        <div className="app-user">
          {stats.active_alerts > 0 && (
            <span className="alert-pill" data-testid="alert-pill">
              <AlertOctagon size={12} /> {stats.active_alerts} OFFICER-DOWN ACTIVE
            </span>
          )}
          <span><span className="live-dot" />LIVE</span>
          <span><b>{user?.name}</b> · {user?.agency} · {user?.role?.toUpperCase()}</span>
          <button className="logout-btn" onClick={doLogout} data-testid="logout-btn">
            <LogOut size={12} style={{verticalAlign:"middle", marginRight:6}} />Sign out
          </button>
        </div>
      </header>

      <main className="app-main">
        <div className="stat-row">
          <Stat label="Active Cases" value={stats.active_cases} />
          <Stat label="Closed Cases" value={stats.closed_cases} />
          <Stat label="Deployed" value={stats.deployed_searchers || 0} />
          <Stat label="Active Alerts" value={stats.active_alerts || 0} />
        </div>

        <div className="section-head">
          <h2 className="section-title">OPERATIONS</h2>
          <button className="btn-primary" onClick={() => setShowCreate(true)} data-testid="new-case-btn">
            <Plus size={14} style={{verticalAlign:"middle"}} /> New Case
          </button>
        </div>

        {cases.length === 0 && (
          <div className="empty-state" data-testid="empty-cases">
            No operations yet. Create a case to coordinate searchers across agencies.
          </div>
        )}

        <div className="case-grid">
          {cases.map((c) => (
            <div key={c.id} className="case-card" onClick={() => navigate(`/cases/${c.id}`)}
                 data-testid={`case-card-${c.id}`}>
              <button className="case-delete-btn"
                      onClick={(e) => deleteCase(e, c.id, c.title)}
                      title="Delete case"
                      data-testid={`delete-case-${c.id}`}>
                <Trash2 size={13} />
              </button>
              <div className="num">CASE #{c.case_number}</div>
              <div className="title">{c.title}</div>
              <div className="meta">
                <span><MapPin size={12} style={{verticalAlign:"middle"}} /> {c.location}</span>
                <span><Users size={12} style={{verticalAlign:"middle"}} /> {c.searcher_count || 0} deployed</span>
                <span><FileText size={12} style={{verticalAlign:"middle"}} /> {c.created_by_agency}</span>
              </div>
              <div style={{marginTop:10}}>
                <span className={`badge ${c.status}`}>{c.status}</span>
                {c.terminated_at && <span className="terminated-stamp">TERMINATED</span>}
              </div>
            </div>
          ))}
        </div>
      </main>

      {showCreate && (
        <CreateCaseModal
          onClose={() => setShowCreate(false)}
          onCreated={() => { setShowCreate(false); load(); }}
        />
      )}
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="stat-card">
      <div className="label">{label}</div>
      <div className="value">{value}</div>
    </div>
  );
}

function CreateCaseModal({ onClose, onCreated }) {
  const [form, setForm] = useState({
    title: "", case_number: "", description: "",
    location: "", center_lat: "", center_lng: "",
  });
  const [saving, setSaving] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    const lat = parseFloat(form.center_lat);
    const lng = parseFloat(form.center_lng);
    if (isNaN(lat) || isNaN(lng)) {
      toast.error("Latitude and Longitude must be numeric");
      return;
    }
    setSaving(true);
    try {
      await api.post("/cases", { ...form, center_lat: lat, center_lng: lng });
      toast.success("Case opened"); onCreated();
    } catch (e) { toast.error(e.response?.data?.detail || "Failed to create"); }
    finally { setSaving(false); }
  };

  return (
    <div className="modal-bg" onClick={onClose}>
      <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}
            data-testid="create-case-modal">
        <h3>OPEN NEW CASE</h3>

        <label className="field-label">Case Number</label>
        <input className="field-input" required value={form.case_number}
               onChange={(e) => setForm({...form, case_number: e.target.value})} data-testid="cc-num" />

        <label className="field-label">Title</label>
        <input className="field-input" required value={form.title}
               onChange={(e) => setForm({...form, title: e.target.value})} data-testid="cc-title" />

        <label className="field-label">Location (city/area)</label>
        <input className="field-input" required value={form.location}
               onChange={(e) => setForm({...form, location: e.target.value})} data-testid="cc-loc" />

        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:14}}>
          <div>
            <label className="field-label">Start Latitude</label>
            <input className="field-input" type="number" step="0.000001" required value={form.center_lat}
                   onChange={(e) => setForm({...form, center_lat: e.target.value})} data-testid="cc-lat" />
          </div>
          <div>
            <label className="field-label">Start Longitude</label>
            <input className="field-input" type="number" step="0.000001" required value={form.center_lng}
                   onChange={(e) => setForm({...form, center_lng: e.target.value})} data-testid="cc-lng" />
          </div>
        </div>

        <label className="field-label">Operational Narrative</label>
        <textarea className="field-input" rows={3} required value={form.description}
                  onChange={(e) => setForm({...form, description: e.target.value})} data-testid="cc-desc" />

        <div style={{display:"flex", gap:12, marginTop:18}}>
          <button type="button" className="btn-outline" onClick={onClose} data-testid="cc-cancel">Cancel</button>
          <button type="submit" className="btn-primary" disabled={saving} data-testid="cc-submit">
            {saving ? "Opening…" : "Open Case"}
          </button>
        </div>
      </form>
    </div>
  );
}
