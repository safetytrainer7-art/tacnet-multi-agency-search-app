import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { LogIn, UserPlus, Mail, Radio, Shield, Lock } from "lucide-react";
import { toast } from "sonner";
import { useAuth, formatApiErrorDetail } from "@/lib/auth";

export default function HomePage() {
  const navigate = useNavigate();
  const { user, login, register } = useAuth();
  const [tab, setTab] = useState("signin");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  if (user) navigate("/dashboard", { replace: true });

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [agency, setAgency] = useState("");
  const [badge, setBadge] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null); setSubmitting(true);
    try {
      if (tab === "signin") {
        await login(email, password);
        toast.success("Authenticated. Welcome to TACNET.");
      } else {
        await register({ email, password, name, agency, badge_number: badge, role: "officer" });
        toast.success("Registration complete. Welcome aboard.");
      }
      navigate("/dashboard");
    } catch (err) {
      setError(formatApiErrorDetail(err.response?.data?.detail) || err.message);
    } finally { setSubmitting(false); }
  };

  return (
    <div className="home" data-testid="home-page">
      <div className="home-left">
        <div className="home-left-content">
          <h1 className="brand-stencil" data-testid="brand-title">TACNET</h1>
          <p className="brand-tagline">
            USA's First Federal · State · Local Multi-Agency Task Force Search Network
          </p>
          <ul className="bullets">
            <li><Radio size={18} strokeWidth={1.5} /> 100% live realtime GPS for every searcher</li>
            <li><Shield size={18} strokeWidth={1.5} /> Outside-agency time-limited token access</li>
            <li><Lock size={18} strokeWidth={1.5} /> Auto-generated court-ready reports</li>
          </ul>
          <div className="creator-credit" data-testid="creator-credit">
            <span className="by">Created By</span>
            Earl Wood · Deputy Sheriff (Retired) · Virginia
          </div>
        </div>
      </div>

      <div className="home-right">
        <form className="signin-card" onSubmit={handleSubmit} data-testid="auth-card">
          <h2 className="signin-title">SECURE SIGN-IN</h2>
          <p className="signin-sub">Authorized Personnel Only</p>
          <hr className="divider-dash" />

          <div className="tab-row">
            <button type="button"
              className={`tab-btn ${tab === "signin" ? "active" : ""}`}
              onClick={() => { setTab("signin"); setError(null); }}
              data-testid="tab-signin">
              <LogIn size={16} /> Sign In
            </button>
            <button type="button"
              className={`tab-btn ${tab === "register" ? "active" : ""}`}
              onClick={() => { setTab("register"); setError(null); }}
              data-testid="tab-register">
              <UserPlus size={16} /> Register
            </button>
          </div>

          {error && <div className="error-banner" data-testid="auth-error">{error}</div>}

          {tab === "register" && (
            <>
              <label className="field-label">Full Name</label>
              <input className="field-input" required value={name}
                     onChange={(e) => setName(e.target.value)} data-testid="input-name" />
              <label className="field-label">Agency</label>
              <input className="field-input" required value={agency}
                     onChange={(e) => setAgency(e.target.value)} data-testid="input-agency" />
              <label className="field-label">Badge Number</label>
              <input className="field-input" value={badge}
                     onChange={(e) => setBadge(e.target.value)} data-testid="input-badge" />
            </>
          )}

          <label className="field-label">Email</label>
          <input type="email" className="field-input" required value={email}
                 onChange={(e) => setEmail(e.target.value)} data-testid="input-email" />

          <label className="field-label">Password</label>
          <input type="password" className="field-input" required value={password}
                 onChange={(e) => setPassword(e.target.value)} data-testid="input-password" />

          <button type="submit" className="primary-btn" disabled={submitting}
                  data-testid="submit-btn">
            <Mail size={16} />
            {submitting ? "Authenticating…" : (tab === "signin" ? "Sign In" : "Register")}
          </button>

          <p className="fine-print">
            By signing in you agree to TACNET operational use only. All search activity is recorded
            for chain-of-custody and court purposes.
          </p>
        </form>
      </div>
    </div>
  );
}
