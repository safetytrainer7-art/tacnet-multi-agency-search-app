import { useEffect, useState, useRef, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  MapContainer, TileLayer, Marker, Popup, Polyline, Circle, useMap, useMapEvents,
} from "react-leaflet";
import L from "leaflet";
import {
  ArrowLeft, FileText, Send, Radio, Shield, RotateCw, Search, Pen, X,
  AlertOctagon, StopCircle, Mail, History, Trash2, Eraser, Layers, Moon,
} from "lucide-react";
import { toast } from "sonner";
import { api, useAuth } from "@/lib/auth";

// ===== Leaflet default icon =====
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
});

// ===== Custom icons =====
const addressDotIcon = new L.DivIcon({
  className: "tac-address-dot",
  html: '<div class="address-dot"></div>',
  iconSize: [16, 16], iconAnchor: [8, 8],
});
const liveSearcherIcon = (color) => new L.DivIcon({
  className: "tac-live",
  html: `<div class="live-pin" style="background:${color}"><span class="live-pulse" style="background:${color}"></span></div>`,
  iconSize: [18, 18], iconAnchor: [9, 9],
});
const manualSearcherIcon = (color) => new L.DivIcon({
  className: "tac-manual",
  html: `<div class="manual-pin" style="background:${color};border-color:${color}"></div>`,
  iconSize: [20, 20], iconAnchor: [10, 20],
});
const downIcon = new L.DivIcon({
  className: "tac-down",
  html: '<div class="down-pin"><span class="down-x">!</span></div>',
  iconSize: [28, 28], iconAnchor: [14, 14],
});

// Agency → color (for live GPS only)
const agencyColor = (a = "") => {
  const map = ["#fde08a","#6df08a","#5dc7ff","#ff8acb","#ffae5d","#c8a2ff","#ff6b6b"];
  let h = 0; for (const ch of a) h = (h * 31 + ch.charCodeAt(0)) & 0xffff;
  return map[h % map.length];
};

// ===== Searcher categories =====
export const CATEGORIES = [
  { key: "LE",       label: "Law Enforcement", color: "#1e6fff" },
  { key: "K9",       label: "K9 Unit",         color: "#5dc7ff" },
  { key: "SAR",      label: "SAR",             color: "#ff2a2a" },
  { key: "CIVILIAN", label: "Civilian",        color: "#39ff7a" },
  { key: "ARTICLE",  label: "Article/Evidence",color: "#ff9a1f" },
  { key: "DRONE",    label: "Drone",           color: "#9aa4ad" },
];
const catColor = (k) => (CATEGORIES.find(c => c.key === (k || "").toUpperCase())?.color) || "#fde08a";
const catLabel = (k) => (CATEGORIES.find(c => c.key === (k || "").toUpperCase())?.label) || k;

// ===== Map controllers =====
function MapFlyTo({ center, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.flyTo(center, zoom || map.getZoom(), { duration: 0.6 });
  }, [center && center[0], center && center[1], zoom, map]);
  return null;
}

function MapInteractionLock({ locked }) {
  const map = useMap();
  useEffect(() => {
    if (locked) {
      map.dragging.disable(); map.scrollWheelZoom.disable();
      map.doubleClickZoom.disable(); map.touchZoom.disable();
      map.boxZoom.disable(); map.keyboard.disable();
    } else {
      map.dragging.enable(); map.scrollWheelZoom.enable();
      map.doubleClickZoom.enable(); map.touchZoom.enable();
      map.boxZoom.enable(); map.keyboard.enable();
    }
  }, [locked, map]);
  return null;
}

function PenDrawingLayer({ active, onComplete }) {
  const map = useMap();
  const drawingRef = useRef(false);
  const ptsRef = useRef([]);
  const polyRef = useRef(null);

  useEffect(() => {
    if (!active) return;
    const start = (e) => {
      drawingRef.current = true;
      ptsRef.current = [[e.latlng.lat, e.latlng.lng]];
      if (polyRef.current) { polyRef.current.remove(); polyRef.current = null; }
      polyRef.current = L.polyline(ptsRef.current, { color: "#ff2a2a", weight: 4, opacity: 0.95 }).addTo(map);
    };
    const move = (e) => {
      if (!drawingRef.current) return;
      ptsRef.current.push([e.latlng.lat, e.latlng.lng]);
      polyRef.current.setLatLngs(ptsRef.current);
    };
    const end = () => {
      if (!drawingRef.current) return;
      drawingRef.current = false;
      const pts = ptsRef.current;
      if (polyRef.current) { polyRef.current.remove(); polyRef.current = null; }
      if (pts.length >= 2) onComplete(pts);
      ptsRef.current = [];
    };
    map.on("mousedown", start);
    map.on("mousemove", move);
    map.on("mouseup", end);
    map.on("mouseout", end);
    return () => {
      map.off("mousedown", start);
      map.off("mousemove", move);
      map.off("mouseup", end);
      map.off("mouseout", end);
      if (polyRef.current) { polyRef.current.remove(); polyRef.current = null; }
    };
  }, [active, map, onComplete]);
  return null;
}

function MapClickToAddSearcher({ enabled, onAdd }) {
  useMapEvents({
    click(e) { if (enabled) onAdd(e.latlng.lat, e.latlng.lng); }
  });
  return null;
}

const LAYERS = {
  street:    { url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
               attr: "&copy; OpenStreetMap" },
  satellite: { url: "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
               attr: "Tiles &copy; Esri — World Imagery" },
  terrain:   { url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
               attr: "&copy; OpenTopoMap (CC-BY-SA) · &copy; OpenStreetMap",
               subdomains: "abc", maxZoom: 17 },
  night:     { url: "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
               attr: "&copy; CARTO &copy; OpenStreetMap", subdomains: "abcd" },
};

// ===== Officer-down alarm sound (Web Audio) =====
function useSiren() {
  const ctxRef = useRef(null);
  const oscRef = useRef(null);
  const stop = useCallback(() => {
    if (oscRef.current) {
      try { oscRef.current.stop(); } catch (e) { console.warn("[TACNET] siren stop:", e); }
      oscRef.current = null;
    }
    if (ctxRef.current) {
      try { ctxRef.current.close(); } catch (e) { console.warn("[TACNET] siren ctx close:", e); }
      ctxRef.current = null;
    }
  }, []);
  const start = useCallback(() => {
    stop();
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sawtooth"; osc.frequency.value = 700;
    gain.gain.value = 0.18;
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    const t0 = ctx.currentTime;
    for (let i = 0; i < 40; i++) {
      osc.frequency.setValueAtTime(700, t0 + i * 0.6);
      osc.frequency.setValueAtTime(1200, t0 + i * 0.6 + 0.3);
    }
    ctxRef.current = ctx; oscRef.current = osc;
  }, [stop]);
  useEffect(() => stop, [stop]);
  return { start, stop };
}

// ===== Main component =====
export default function CaseDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [c, setCase] = useState(null);
  const [searchers, setSearchers] = useState([]);   // live GPS
  const [manualSearchers, setManualSearchers] = useState([]);
  const [audit, setAudit] = useState([]);
  const [tokens, setTokens] = useState([]);
  const [pings, setPings] = useState([]);
  const [drawings, setDrawings] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [timeline, setTimeline] = useState([]);

  const [radius, setRadius] = useState(500);
  const [addressQuery, setAddressQuery] = useState("");
  const [searching, setSearching] = useState(false);
  const [flyTarget, setFlyTarget] = useState(null);
  const [penActive, setPenActive] = useState(false);
  const [eraserActive, setEraserActive] = useState(false);
  const [armedCategory, setArmedCategory] = useState(null); // category key being placed
  const [showToken, setShowToken] = useState(false);
  const [showTimeline, setShowTimeline] = useState(false);
  const [showEmail, setShowEmail] = useState(false);
  const [showTerminate, setShowTerminate] = useState(false);
  const [tracking, setTracking] = useState(false);
  const [mapLayer, setMapLayer] = useState("street"); // street|satellite|terrain|night
  const trackingRef = useRef(null);
  const siren = useSiren();
  const closed = c?.status === "closed";

  const load = async () => {
    try {
      const [cr, sr, ar, tr, pr, msr, dr, al] = await Promise.all([
        api.get(`/cases/${id}`),
        api.get(`/cases/${id}/searchers`),
        api.get(`/cases/${id}/audit`),
        api.get(`/cases/${id}/guest-tokens`),
        api.get(`/cases/${id}/pings`),
        api.get(`/cases/${id}/manual-searchers`),
        api.get(`/cases/${id}/drawings`),
        api.get(`/cases/${id}/alerts/active`),
      ]);
      setCase(cr.data); setSearchers(sr.data); setAudit(ar.data); setTokens(tr.data);
      setPings(pr.data); setManualSearchers(msr.data); setDrawings(dr.data); setAlerts(al.data);
      if (cr.data?.perimeter_radius_m) setRadius((r) => (r === 500 ? cr.data.perimeter_radius_m : r));
    } catch (e) {
      toast.error("Failed to load case");
    }
  };

  useEffect(() => { load(); const i = setInterval(load, 5000); return () => clearInterval(i); }, [id]);

  // Officer-down siren + flash
  useEffect(() => {
    if (alerts.length > 0) siren.start(); else siren.stop();
  }, [alerts.length, siren]);

  // ===== Address search =====
  const doAddressSearch = async () => {
    if (!addressQuery.trim()) return;
    setSearching(true);
    try {
      const { data } = await api.get(`/geocode`, { params: { q: addressQuery } });
      setFlyTarget([data.lat, data.lng]);
      await api.put(`/cases/${id}/perimeter`, {
        center_lat: data.lat, center_lng: data.lng,
        radius_m: radius, address: data.display_name,
      });
      toast.success(`Located: ${data.display_name}`);
      load();
    } catch (e) {
      toast.error(e.response?.data?.detail || "Address not found");
    } finally { setSearching(false); }
  };

  // ===== Radius adjust =====
  const commitRadius = async (val) => {
    if (!c) return;
    try {
      await api.put(`/cases/${id}/perimeter`, {
        center_lat: c.center_lat, center_lng: c.center_lng,
        radius_m: val, address: c.perimeter_address || "",
      });
      load();
    } catch (e) {
      console.warn("[TACNET] perimeter update failed:", e);
      toast.error("Failed to save perimeter radius");
    }
  };

  // ===== GPS Tracking =====
  const sendPing = async (lat, lng, accuracy) => {
    try {
      await api.post("/pings", { case_id: id, lat, lng, accuracy });
    } catch (e) {
      console.warn("[TACNET] position broadcast failed:", e);
    }
  };
  const sendSimulated = async () => {
    if (!c) return;
    const lat = c.center_lat + (Math.random() - 0.5) * 0.01;
    const lng = c.center_lng + (Math.random() - 0.5) * 0.01;
    await sendPing(lat, lng, 5 + Math.random() * 15);
    toast.success("Position broadcast");
    load();
  };  const toggleTracking = () => {
    if (tracking) {
      if (trackingRef.current) navigator.geolocation.clearWatch(trackingRef.current);
      trackingRef.current = null;
      setTracking(false);
      toast.info("Live tracking stopped");
      return;
    }
    if (!("geolocation" in navigator)) {
      toast.warning("Geolocation unavailable — broadcasting simulated position instead");
      sendSimulated(); return;
    }
    trackingRef.current = navigator.geolocation.watchPosition(
      (pos) => sendPing(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy),
      () => {
        if (trackingRef.current) navigator.geolocation.clearWatch(trackingRef.current);
        trackingRef.current = null; setTracking(false);
        toast.warning("GPS permission denied — broadcasting simulated position instead");
        sendSimulated();
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
    );
    setTracking(true);
    toast.success("Live GPS tracking active");
  };

  // ===== Drawings =====
  const onDrawComplete = async (pts) => {
    try {
      await api.post("/drawings", { case_id: id, points: pts, color: "#ff2a2a" });
      load();
    } catch { toast.error("Failed to save drawing"); }
  };
  const clearDrawings = async () => {
    if (!confirm("Clear all map annotations? This cannot be undone.")) return;
    await api.delete(`/cases/${id}/drawings`);
    toast.success("All drawings cleared");
    load();
  };

  // ===== Manual searcher (instant drop by category) =====
  const placeSearcherAt = async (lat, lng) => {
    if (!armedCategory) return;
    try {
      await api.post("/manual-searchers", {
        case_id: id, lat, lng,
        category: armedCategory,
        agency: user?.agency,
      });
      toast.success(`${catLabel(armedCategory)} deployed`);
      load();
    } catch (e) {
      console.warn("[TACNET] place searcher failed:", e);
      toast.error("Failed to deploy");
    }
  };
  const removeManual = async (msId) => {
    if (!confirm("Remove this searcher from the grid?")) return;
    await api.delete(`/manual-searchers/${msId}`);
    toast.success("Searcher removed");
    load();
  };

  // ===== Eraser — click a drawing to delete it =====
  const eraseDrawing = async (drawingId) => {
    try {
      await api.delete(`/drawings/${drawingId}`);
      toast.success("Annotation erased");
      load();
    } catch (e) {
      console.warn("[TACNET] erase failed:", e);
      toast.error("Failed to erase");
    }
  };

  // ===== Officer down =====
  const triggerOfficerDown = async () => {
    if (!confirm("CONFIRM: TRIGGER OFFICER-DOWN ALARM?\nThis alerts every connected officer with an audible siren.")) return;
    try {
      let lat = c.center_lat, lng = c.center_lng;
      if ("geolocation" in navigator) {
        await new Promise((res) => navigator.geolocation.getCurrentPosition(
          (p) => { lat = p.coords.latitude; lng = p.coords.longitude; res(); },
          () => res(), { timeout: 4000 }
        ));
      }
      await api.post("/officer-down", { case_id: id, lat, lng });
      toast.error("OFFICER-DOWN ALERT BROADCAST");
      load();
    } catch { toast.error("Failed to send alert"); }
  };
  const resetAlert = async (alertId) => {
    await api.post(`/alerts/${alertId}/reset`);
    toast.success("Alert reset");
    load();
  };

  // ===== Terminate =====
  const terminate = async () => {
    try {
      await api.post(`/cases/${id}/terminate`);
      toast.success("SEARCH TERMINATED — all state preserved");
      setShowTerminate(false);
      load();
    } catch (e) {
      toast.error(e.response?.data?.detail || "Failed to terminate");
    }
  };

  // ===== Reports =====
  const downloadReport = async () => {
    const loadingToast = toast.loading("Generating court-ready PDF…");
    try {
      const res = await api.get(`/cases/${id}/report`, { responseType: "blob" });
      const blob = new Blob([res.data], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const filename = `TACNET_${c.case_number || "report"}_${new Date().toISOString().slice(0,10)}.pdf`;
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      a.rel = "noopener";
      a.style.display = "none";
      document.body.appendChild(a);
      a.click();
      // delay cleanup so Safari has time to start the download
      setTimeout(() => {
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 1500);
      toast.dismiss(loadingToast);
      toast.success(`Report downloaded: ${filename}`, { duration: 6000 });
    } catch (err) {
      toast.dismiss(loadingToast);
      console.warn("[TACNET] report download failed:", err);
      toast.error("Report generation failed — check connection and try again");
    }
  };

  // ===== Timeline =====
  const openTimeline = async () => {
    try {
      const { data } = await api.get(`/cases/${id}/timeline`);
      setTimeline(data);
      setShowTimeline(true);
    } catch { toast.error("Failed to load recording"); }
  };

  if (!c) return <div className="tac-loading">LOADING CASE…</div>;

  return (
    <div className="app-shell">
      {/* Officer-down full screen flash overlay */}
      {alerts.length > 0 && (
        <div className="emergency-flash" data-testid="emergency-flash">
          <div className="emergency-box">
            <AlertOctagon size={56} color="#fff" />
            <h2>OFFICER DOWN</h2>
            {alerts.map(a => (
              <div key={a.id} className="emergency-line">
                <b>{a.officer_name}</b> · {a.officer_agency}
                {a.lat && a.lng ? ` @ ${a.lat.toFixed(5)}, ${a.lng.toFixed(5)}` : ""}
                <button className="reset-alert-btn" onClick={() => resetAlert(a.id)}
                        data-testid={`reset-alert-${a.id}`}>
                  RESET
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <header className="app-header">
        <div className="app-brand">
          TACNET
          <span className="creator-sub">Earl Wood · Dep. Sheriff (Ret.) · VA</span>
        </div>
        <div className="app-user">
          <span><span className="live-dot" />LIVE</span>
          <span><b>{user?.name}</b> · {user?.agency}</span>
          <button className="logout-btn" onClick={() => navigate("/dashboard")}>Dashboard</button>
        </div>
      </header>

      <main className="app-main">
        <button className="back-btn" onClick={() => navigate("/dashboard")} data-testid="back-btn">
          <ArrowLeft size={14} /> Back to Operations
        </button>

        <div className="section-head">
          <div>
            <div className="case-meta-line">
              CASE #{c.case_number} <span className={`badge ${c.status}`}>{c.status}</span>
              {closed && <span className="terminated-stamp">TERMINATED {c.terminated_at?.slice(0,19).replace('T',' ')}</span>}
            </div>
            <h2 className="section-title" style={{marginTop:4}}>{c.title}</h2>
            <div className="case-location">{c.location}</div>
          </div>
          <div className="action-bar">
            <button className="btn-emergency" onClick={triggerOfficerDown}
                    disabled={closed} data-testid="officer-down-btn">
              <AlertOctagon size={14} /> OFFICER DOWN
            </button>
            <button className="btn-outline" onClick={openTimeline} data-testid="timeline-btn">
              <History size={12} /> Recording
            </button>
            <button className="btn-outline" onClick={() => setShowToken(true)}
                    disabled={closed} data-testid="issue-token-btn">
              <Shield size={12} /> Guest Token
            </button>
            <button className="btn-outline" onClick={() => setShowEmail(true)} data-testid="email-report-btn">
              <Mail size={12} /> Email Report
            </button>
            <button className="btn-primary" onClick={downloadReport} data-testid="report-btn">
              <FileText size={12} /> PDF Report
            </button>
            <button className="btn-terminate" onClick={() => setShowTerminate(true)}
                    disabled={closed} data-testid="terminate-btn">
              <StopCircle size={14} /> Terminate Search
            </button>
          </div>
        </div>

        {/* Address search row */}
        <div className="address-bar">
          <Search size={16} color="#6df08a" />
          <input
            value={addressQuery}
            onChange={(e) => setAddressQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && doAddressSearch()}
            disabled={closed}
            data-testid="address-input"
          />
          <button onClick={doAddressSearch} disabled={searching || closed}
                  className="go-btn" data-testid="go-btn">
            {searching ? "LOCATING…" : "GO"}
          </button>
          <div className="radius-control">
            <span className="ctrl-label">PERIMETER</span>
            <input type="range" min="50" max="5000" step="50"
                   value={radius}
                   onChange={(e) => setRadius(+e.target.value)}
                   onMouseUp={() => commitRadius(radius)}
                   onTouchEnd={() => commitRadius(radius)}
                   disabled={closed}
                   data-testid="radius-slider" />
            <span className="ctrl-value">{radius} m</span>
          </div>
        </div>

        {/* Tool row */}
        <div className="tool-bar">
          <button className={`tool ${penActive ? "active":""}`}
                  onClick={() => { setPenActive(!penActive); setEraserActive(false); setArmedCategory(null); }}
                  disabled={closed} data-testid="pen-btn">
            <Pen size={13} /> Red Pen {penActive ? "(map locked)" : ""}
          </button>
          <button className={`tool ${eraserActive ? "active":""}`}
                  onClick={() => { setEraserActive(!eraserActive); setPenActive(false); setArmedCategory(null); }}
                  disabled={closed || drawings.length === 0} data-testid="eraser-btn">
            <Eraser size={13} /> Eraser {eraserActive ? "(click line)" : ""}
          </button>
          <button className="tool" onClick={clearDrawings}
                  disabled={closed || drawings.length === 0} data-testid="clear-pen-btn">
            <X size={13} /> Clear All
          </button>
          <button className={`tool ${tracking ? "active":""}`}
                  onClick={toggleTracking} disabled={closed} data-testid="track-btn">
            <Radio size={13} /> {tracking ? "Stop Live GPS" : "My Live GPS"}
          </button>
          <button className="tool" onClick={sendSimulated} disabled={closed} data-testid="sim-btn">
            <RotateCw size={13} /> Drop Test Position
          </button>

          {/* Map layer switcher */}
          <div className="layer-switcher">
            <Layers size={13} color="#fde08a" />
            {Object.keys(LAYERS).map((k) => (
              <button key={k}
                      className={`layer-btn ${mapLayer === k ? "active":""} ${k === "night" ? "night":""}`}
                      onClick={() => setMapLayer(k)}
                      data-testid={`layer-${k}`}>
                {k === "night" ? <><Moon size={11} /> Night Vision</> : k.charAt(0).toUpperCase() + k.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {/* Place-Searcher category row */}
        <div className="category-row" data-testid="category-row">
          <span className="ctrl-label" style={{paddingRight:8}}>PLACE SEARCHER</span>
          {CATEGORIES.map((c) => (
            <button key={c.key}
                    className={`cat-dot ${armedCategory === c.key ? "active" : ""}`}
                    style={{["--cat-color"]: c.color}}
                    onClick={() => {
                      setArmedCategory(armedCategory === c.key ? null : c.key);
                      setPenActive(false); setEraserActive(false);
                    }}
                    disabled={closed}
                    title={c.label}
                    data-testid={`cat-${c.key}`}>
              <span className="dot" />
              <span className="cat-name">{c.label}</span>
            </button>
          ))}
          {armedCategory && (
            <span className="armed-hint">
              Tap the map to drop a <b style={{color: catColor(armedCategory)}}>{catLabel(armedCategory)}</b> marker
            </span>
          )}
        </div>

        <p className="case-narrative">{c.description}</p>

        <div className="case-detail-grid">
          <div className="panel" style={{padding:0, overflow:"hidden"}}>
            <div className={`map-host ${mapLayer === "night" ? "night-vision" : ""}`} data-testid="map-host">
              <MapContainer center={[c.center_lat, c.center_lng]} zoom={14} scrollWheelZoom={true}>
                <TileLayer
                  key={mapLayer}
                  url={LAYERS[mapLayer].url}
                  attribution={LAYERS[mapLayer].attr}
                  subdomains={LAYERS[mapLayer].subdomains || "abc"}
                  maxZoom={LAYERS[mapLayer].maxZoom || 19}
                />
                <MapFlyTo center={flyTarget} zoom={15} />
                <MapInteractionLock locked={penActive} />
                <MapClickToAddSearcher enabled={!!armedCategory && !penActive && !eraserActive}
                                       onAdd={placeSearcherAt} />
                <PenDrawingLayer active={penActive} onComplete={onDrawComplete} />

                {/* Neon green perimeter */}
                <Circle center={[c.center_lat, c.center_lng]} radius={c.perimeter_radius_m || radius}
                        pathOptions={{
                          color: "#39ff7a", weight: 3, opacity: 0.95,
                          fillColor: "#39ff7a", fillOpacity: 0.08,
                          dashArray: "8 4",
                        }} />

                {/* Address red dot */}
                <Marker position={[c.center_lat, c.center_lng]} icon={addressDotIcon}>
                  <Popup>
                    <b>Search Origin</b><br/>
                    {c.perimeter_address || c.location}<br/>
                    <span style={{color:"#666"}}>
                      {c.center_lat.toFixed(6)}, {c.center_lng.toFixed(6)}
                    </span>
                  </Popup>
                </Marker>

                {/* Live GPS searchers */}
                {searchers.map((s) => (
                  <Marker key={s.user_id} position={[s.lat, s.lng]} icon={liveSearcherIcon(agencyColor(s.agency))}>
                    <Popup>
                      <b>{s.user_name}</b> (LIVE GPS)<br/>
                      {s.agency}<br/>
                      {new Date(s.ts).toLocaleTimeString()}
                    </Popup>
                  </Marker>
                ))}

                {/* Manually placed searchers (by category color) */}
                {manualSearchers.map((m) => (
                  <Marker key={m.id} position={[m.lat, m.lng]}
                          icon={manualSearcherIcon(catColor(m.category))}>
                    <Popup>
                      <b>{m.name}</b><br/>
                      {catLabel(m.category || "LE")}<br/>
                      <span style={{color:"#666"}}>{m.agency}</span><br/>
                      Placed by {m.placed_by}<br/>
                      <button onClick={() => removeManual(m.id)}
                              style={{background:"#ff2a2a",color:"white",border:0,padding:"4px 10px",cursor:"pointer",marginTop:6}}>
                        Remove
                      </button>
                    </Popup>
                  </Marker>
                ))}

                {/* Officer-down markers */}
                {alerts.filter(a => a.lat && a.lng).map(a => (
                  <Marker key={a.id} position={[a.lat, a.lng]} icon={downIcon}>
                    <Popup>
                      <b style={{color:"#ff2a2a"}}>OFFICER DOWN</b><br/>
                      {a.officer_name} ({a.officer_agency})<br/>
                      {new Date(a.triggered_at).toLocaleTimeString()}
                    </Popup>
                  </Marker>
                ))}

                {/* GPS path */}
                {pings.length > 1 && (
                  <Polyline positions={pings.map(p => [p.lat, p.lng])}
                            pathOptions={{ color: "#fde08a", weight: 2, opacity: 0.7 }} />
                )}

                {/* Saved freehand drawings — click in eraser mode to delete */}
                {drawings.map((d) => (
                  <Polyline key={d.id} positions={d.points}
                            pathOptions={{ color: d.color || "#ff2a2a",
                                           weight: eraserActive ? 7 : 4,
                                           opacity: 0.95 }}
                            eventHandlers={eraserActive ? { click: () => eraseDrawing(d.id) } : {}} />
                ))}
              </MapContainer>
            </div>
          </div>

          <div className="right-col">
            <div className="panel">
              <h4>LIVE GPS · {searchers.length}</h4>
              {searchers.length === 0 && <div className="empty-state">No live signals — officers must start GPS</div>}
              {searchers.map((s) => (
                <div key={s.user_id} className="searcher-row" data-testid={`live-${s.user_id}`}>
                  <div className="who">
                    <span className="color-dot" style={{background:agencyColor(s.agency)}} />
                    <b>{s.user_name}</b><br/>
                    <span style={{color:"var(--tac-muted)"}}>{s.agency}</span>
                  </div>
                  <div className="where">
                    {s.lat.toFixed(5)}, {s.lng.toFixed(5)}<br/>
                    <span style={{color:"var(--tac-muted)"}}>{new Date(s.ts).toLocaleTimeString()}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="panel">
              <h4>DEPLOYED · {manualSearchers.length}</h4>
              {manualSearchers.length === 0 &&
                <div className="empty-state">Pick a category dot then tap the map to deploy</div>}
              {manualSearchers.map((m) => (
                <div key={m.id} className="searcher-row" data-testid={`manual-${m.id}`}>
                  <div className="who">
                    <span className="color-dot" style={{background:catColor(m.category)}} />
                    <b>{m.name}</b><br/>
                    <span style={{color:"var(--tac-muted)"}}>{catLabel(m.category || "LE")} · {m.agency}</span>
                  </div>
                  <div className="where" style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4}}>
                    <span>{m.lat.toFixed(5)}, {m.lng.toFixed(5)}</span>
                    <button className="mini-btn" onClick={() => removeManual(m.id)}
                            data-testid={`remove-manual-${m.id}`}>
                      <Trash2 size={10} /> Remove
                    </button>
                  </div>
                </div>
              ))}
            </div>

            <div className="panel">
              <h4>GUEST TOKENS · {tokens.length}</h4>
              {tokens.length === 0 && <div className="empty-state">No outside-agency tokens</div>}
              {tokens.map((t) => (
                <div key={t.id} className="token-card" data-testid={`token-${t.id}`}>
                  <div style={{display:"flex", justifyContent:"space-between"}}>
                    <b style={{color:"var(--tac-text)"}}>{t.contact_name}</b>
                    {t.revoked
                      ? <span style={{color:"var(--tac-red)"}}>REVOKED</span>
                      : <span style={{color:"#6df08a"}}>ACTIVE</span>}
                  </div>
                  <div style={{color:"var(--tac-muted)"}}>{t.agency} · {t.contact_email}</div>
                  <code className="token-string">{t.token}</code>
                  <div style={{color:"var(--tac-muted)"}}>Expires: {new Date(t.expires_at).toLocaleString()}</div>
                  {!t.revoked && (
                    <button className="mini-btn"
                            onClick={async () => { await api.post(`/guest-tokens/${t.id}/revoke`); toast.success("Token revoked"); load(); }}>
                      Revoke
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>

      {showToken && <IssueTokenModal caseId={id}
                       onClose={() => setShowToken(false)}
                       onDone={() => { setShowToken(false); load(); }} />}
      {showTimeline && <TimelineModal events={timeline}
                       onClose={() => setShowTimeline(false)} />}
      {showEmail && <EmailReportModal caseId={id} onClose={() => setShowEmail(false)} />}
      {showTerminate && <ConfirmTerminateModal
                       onCancel={() => setShowTerminate(false)}
                       onConfirm={terminate} />}
    </div>
  );
}

function IssueTokenModal({ caseId, onClose, onDone }) {
  const [f, setF] = useState({ agency: "", contact_name: "", contact_email: "", hours_valid: 24 });
  const [issued, setIssued] = useState(null);
  const [saving, setSaving] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      const { data } = await api.post("/guest-tokens", { case_id: caseId, ...f, hours_valid: +f.hours_valid });
      setIssued(data); toast.success("Token issued");
    } catch { toast.error("Failed to issue token"); }
    finally { setSaving(false); }
  };
  return (
    <div className="modal-bg" onClick={onClose}>
      <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <h3>ISSUE GUEST TOKEN</h3>
        {!issued ? (
          <>
            <label className="field-label">Outside Agency</label>
            <input className="field-input" required value={f.agency}
                   onChange={(e) => setF({...f, agency: e.target.value})} data-testid="gt-agency" />
            <label className="field-label">Contact Name</label>
            <input className="field-input" required value={f.contact_name}
                   onChange={(e) => setF({...f, contact_name: e.target.value})} data-testid="gt-name" />
            <label className="field-label">Contact Email</label>
            <input type="email" className="field-input" required value={f.contact_email}
                   onChange={(e) => setF({...f, contact_email: e.target.value})} data-testid="gt-email" />
            <label className="field-label">Hours Valid (1–168)</label>
            <input type="number" className="field-input" required min={1} max={168}
                   value={f.hours_valid}
                   onChange={(e) => setF({...f, hours_valid: e.target.value})} data-testid="gt-hours" />
            <div style={{display:"flex", gap:12, marginTop:18}}>
              <button type="button" className="btn-outline" onClick={onClose}>Cancel</button>
              <button type="submit" className="btn-primary" disabled={saving} data-testid="gt-submit">
                <Send size={12}/> {saving ? "Issuing…" : "Issue Token"}
              </button>
            </div>
          </>
        ) : (
          <>
            <p style={{color:"var(--tac-muted)", fontFamily:"'Share Tech Mono'", fontSize:12}}>
              Share with {issued.contact_name}. Expires {new Date(issued.expires_at).toLocaleString()}.
            </p>
            <code className="token-string" style={{fontSize:14, padding:12, background:"rgba(0,0,0,0.4)", display:"block"}}>
              {issued.token}
            </code>
            <button className="btn-primary" onClick={onDone} style={{marginTop:14, width:"100%"}}>Done</button>
          </>
        )}
      </form>
    </div>
  );
}

function TimelineModal({ events, onClose }) {
  return (
    <div className="modal-bg" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()} style={{maxWidth:780, maxHeight:"80vh", overflow:"auto"}}>
        <h3>OPERATION RECORDING — {events.length} EVENTS</h3>
        {events.length === 0 && <div className="empty-state">No events recorded</div>}
        <div className="timeline">
          {events.map((e, i) => (
            <div key={`${e.ts}-${e.kind}-${i}`} className={`timeline-row kind-${e.kind}`}>
              <span className="ts">{new Date(e.ts).toLocaleString()}</span>
              <span className={`kind-tag kind-${e.kind}`}>{e.kind}</span>
              <span className="actor">{e.actor}</span>
              <span className="detail">{e.action ? <b>{e.action}: </b> : null}{e.detail}</span>
            </div>
          ))}
        </div>
        <button className="btn-primary" onClick={onClose} style={{marginTop:14}}>Close</button>
      </div>
    </div>
  );
}

function EmailReportModal({ caseId, onClose }) {
  const [recipients, setRecipients] = useState("");
  const [saving, setSaving] = useState(false);
  const submit = async (e) => {
    e.preventDefault(); setSaving(true);
    try {
      const list = recipients.split(/[,;\s]+/).filter(Boolean);
      const { data: emailPrep } = await api.post(`/cases/${caseId}/report/email`, { recipients: list });
      // Download the PDF first so officer can attach
      const res = await api.get(`/cases/${caseId}/report`, { responseType: "blob" });
      const url = URL.createObjectURL(res.data);
      const a = document.createElement("a"); a.href = url; a.download = `TACNET_report.pdf`; a.click();
      URL.revokeObjectURL(url);
      // Open mail client
      window.location.href = emailPrep.mailto;
      toast.success("PDF downloaded — mail client opened. Attach the PDF before sending.");
      onClose();
    } catch (err) {
      toast.error(err.response?.data?.detail || "Failed to prepare email");
    } finally { setSaving(false); }
  };
  return (
    <div className="modal-bg" onClick={onClose}>
      <form className="modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
        <h3>EMAIL FINAL REPORT</h3>
        <p style={{color:"var(--tac-muted)", fontFamily:"'Share Tech Mono'", fontSize:11, lineHeight:1.6}}>
          The court-ready PDF will be downloaded to this device and your default mail client will open
          pre-filled with subject, body, and recipients. Attach the downloaded PDF before sending —
          this preserves chain-of-custody.
        </p>
        <label className="field-label">Recipient Emails (comma-separated)</label>
        <input className="field-input" required value={recipients}
               onChange={(e) => setRecipients(e.target.value)}
               data-testid="email-recipients" />
        <div style={{display:"flex", gap:12, marginTop:18}}>
          <button type="button" className="btn-outline" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn-primary" disabled={saving} data-testid="email-submit">
            <Mail size={12} /> {saving ? "Preparing…" : "Prepare Email"}
          </button>
        </div>
      </form>
    </div>
  );
}

function ConfirmTerminateModal({ onCancel, onConfirm }) {
  return (
    <div className="modal-bg" onClick={onCancel}>
      <div className="modal terminate-modal" onClick={(e) => e.stopPropagation()}>
        <h3 style={{color:"#ff6b6b"}}>TERMINATE SEARCH</h3>
        <p style={{color:"var(--tac-text)", fontFamily:"'Share Tech Mono'", fontSize:12, lineHeight:1.7}}>
          This ends the operation immediately. All GPS positions, deployed searchers, drawings,
          guest tokens, alerts, and audit events are <b style={{color:"#fde08a"}}>preserved in full</b> and
          locked from further modification. The complete recording remains accessible for the final
          report and court submission.
        </p>
        <p style={{color:"#ff6b6b", fontFamily:"'Share Tech Mono'", fontSize:11, marginTop:14}}>
          THIS ACTION CANNOT BE REVERSED.
        </p>
        <div style={{display:"flex", gap:12, marginTop:18}}>
          <button className="btn-outline" onClick={onCancel} data-testid="terminate-cancel">Cancel</button>
          <button className="btn-terminate" onClick={onConfirm} data-testid="terminate-confirm">
            <StopCircle size={14} /> Terminate Now
          </button>
        </div>
      </div>
    </div>
  );
}
