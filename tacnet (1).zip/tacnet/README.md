# TACNET — Multi-Agency Task Force Search Network

USA's first Federal · State · Local multi-agency live-search coordination app.

**Created by:** Earl Wood · Deputy Sheriff (Retired) · Virginia

## Quick Start

### Backend
```bash
cd backend
pip install -r requirements.txt
# Make sure MongoDB is running locally on 27017
uvicorn server:app --reload --port 8001
```

### Frontend
```bash
cd frontend
yarn install   # or: npm install
yarn start     # or: npm start
```

Open http://localhost:3000, register an account, and you're operational.

## Features
- Multi-agency case management with cascade delete
- Address search (Photon geocoder) + adjustable neon-green perimeter
- Live GPS broadcast for every searcher (with simulated test ping fallback)
- Place Searcher by category: Law Enforcement (blue) · K9 (light blue) · SAR (red) · Civilian (green) · Article/Evidence (orange) · Drone (grey)
- Red-pen freehand annotations with eraser (map locks while drawing)
- Map layers: Street · Satellite · Terrain · Night Vision
- OFFICER DOWN audible/flashing alarm with per-alert reset
- Terminate Search — preserves all evidence, locks edits
- Outside-agency time-limited guest tokens
- Full operation recording / chronological timeline
- Branded court-ready PDF report (downloadable + email-prefill)

## Stack
- Backend: FastAPI · MongoDB (Motor async) · bcrypt · PyJWT · ReportLab
- Frontend: React 19 · React-Leaflet · Sonner · Lucide

## Environment
A fresh `JWT_SECRET` has been pre-generated in `backend/.env`.
Replace `REACT_APP_BACKEND_URL` in `frontend/.env` with your production URL when deploying.
