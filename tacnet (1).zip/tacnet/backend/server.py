from dotenv import load_dotenv
from pathlib import Path
ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

import os
import io
import uuid
import logging
import secrets
import urllib.parse
from datetime import datetime, timezone, timedelta
from typing import Optional, List

import bcrypt
import jwt
import requests
from fastapi import FastAPI, APIRouter, HTTPException, Request, Response, Depends
from fastapi.responses import StreamingResponse
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel, Field, EmailStr

from reportlab.lib.pagesizes import LETTER
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table,
                                TableStyle, Image as RLImage, PageBreak, KeepTogether)
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.pdfgen import canvas as rl_canvas
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Polygon
from reportlab.graphics import renderPDF


# ============= App / DB Setup =============
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

app = FastAPI(title="TACNET API")
api_router = APIRouter(prefix="/api")

JWT_SECRET = os.environ['JWT_SECRET']
JWT_ALG = "HS256"


# ============= Helpers =============
def now_utc() -> datetime:
    return datetime.now(timezone.utc)

def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat()

def hash_password(p: str) -> str:
    return bcrypt.hashpw(p.encode(), bcrypt.gensalt()).decode()

def verify_password(p: str, h: str) -> bool:
    try:
        return bcrypt.checkpw(p.encode(), h.encode())
    except Exception:
        return False

def create_access_token(uid: str, email: str) -> str:
    payload = {"sub": uid, "email": email, "type": "access",
               "exp": now_utc() + timedelta(hours=12)}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

def decode_token(token: str) -> dict:
    return jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])


async def get_current_user(request: Request) -> dict:
    token = request.cookies.get("access_token")
    if not token:
        auth = request.headers.get("Authorization", "")
        if auth.startswith("Bearer "):
            token = auth[7:]
    if not token:
        raise HTTPException(401, "Not authenticated")
    try:
        payload = decode_token(token)
        if payload.get("type") != "access":
            raise HTTPException(401, "Invalid token type")
        user = await db.users.find_one({"id": payload["sub"]}, {"password_hash": 0, "_id": 0})
        if not user:
            raise HTTPException(401, "User not found")
        return user
    except jwt.ExpiredSignatureError:
        raise HTTPException(401, "Token expired")
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")


def set_auth_cookie(response: Response, token: str):
    response.set_cookie(
        key="access_token", value=token,
        httponly=True, secure=True, samesite="none",
        max_age=12*60*60, path="/"
    )


# ============= Models =============
class RegisterIn(BaseModel):
    email: EmailStr
    password: str
    name: str
    agency: str
    badge_number: Optional[str] = None
    role: Optional[str] = "officer"

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class CaseIn(BaseModel):
    title: str
    case_number: str
    description: str
    location: str
    center_lat: float
    center_lng: float
    status: Optional[str] = "active"
    perimeter_radius_m: Optional[float] = 500.0

class CaseUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None

class PingIn(BaseModel):
    case_id: str
    lat: float
    lng: float
    accuracy: Optional[float] = None
    note: Optional[str] = None

class GuestTokenIn(BaseModel):
    case_id: str
    agency: str
    contact_name: str
    contact_email: EmailStr
    hours_valid: int = 24

class PerimeterIn(BaseModel):
    center_lat: float
    center_lng: float
    radius_m: float
    address: Optional[str] = None

class ManualSearcherIn(BaseModel):
    case_id: str
    name: Optional[str] = None
    agency: Optional[str] = None
    lat: float
    lng: float
    category: Optional[str] = "LE"  # LE | K9 | SAR | CIVILIAN | ARTICLE | DRONE

class DrawingIn(BaseModel):
    case_id: str
    points: List[List[float]]  # [[lat,lng], ...]
    color: Optional[str] = "#ff2a2a"

class OfficerDownIn(BaseModel):
    case_id: str
    lat: Optional[float] = None
    lng: Optional[float] = None
    note: Optional[str] = None

class EmailReportIn(BaseModel):
    recipients: List[EmailStr]


# ============= Auth Routes =============
@api_router.post("/auth/register")
async def register(data: RegisterIn, response: Response):
    email = data.email.lower().strip()
    if await db.users.find_one({"email": email}):
        raise HTTPException(409, "Email already registered")
    uid = str(uuid.uuid4())
    user_doc = {
        "id": uid,
        "email": email,
        "password_hash": hash_password(data.password),
        "name": data.name,
        "agency": data.agency,
        "badge_number": data.badge_number or "",
        "role": data.role or "officer",
        "created_at": iso(now_utc()),
    }
    await db.users.insert_one(user_doc)
    token = create_access_token(uid, email)
    set_auth_cookie(response, token)
    user_doc.pop("password_hash")
    user_doc.pop("_id", None)
    return {"user": user_doc, "token": token}


@api_router.post("/auth/login")
async def login(data: LoginIn, response: Response):
    email = data.email.lower().strip()
    user = await db.users.find_one({"email": email})
    if not user or not verify_password(data.password, user.get("password_hash", "")):
        raise HTTPException(401, "Invalid email or password")
    token = create_access_token(user["id"], user["email"])
    set_auth_cookie(response, token)
    user.pop("password_hash", None)
    user.pop("_id", None)
    return {"user": user, "token": token}


@api_router.get("/auth/me")
async def me(user: dict = Depends(get_current_user)):
    return user


@api_router.post("/auth/logout")
async def logout(response: Response):
    response.delete_cookie("access_token", path="/")
    return {"ok": True}


# ============= Geocode =============
@api_router.get("/geocode")
async def geocode(q: str, user: dict = Depends(get_current_user)):
    if not q or len(q.strip()) < 3:
        raise HTTPException(400, "Query too short")
    # Try Photon (komoot, OSM-based, no key, no strict limits)
    try:
        r = requests.get(
            "https://photon.komoot.io/api",
            params={"q": q, "limit": 1},
            headers={"User-Agent": "TACNET/1.0"},
            timeout=8,
        )
        r.raise_for_status()
        data = r.json()
        feats = data.get("features") or []
        if feats:
            f = feats[0]
            coords = f.get("geometry", {}).get("coordinates", [])
            if len(coords) >= 2:
                lng, lat = coords[0], coords[1]
                props = f.get("properties", {})
                parts = [props.get(k) for k in ("name", "street", "housenumber", "city", "state", "country") if props.get(k)]
                display = ", ".join(parts) if parts else q
                return {
                    "lat": float(lat), "lng": float(lng),
                    "display_name": display,
                    "type": props.get("type", ""),
                    "class": props.get("osm_key", ""),
                }
    except requests.RequestException:
        pass
    # Fallback: Nominatim
    try:
        r = requests.get(
            "https://nominatim.openstreetmap.org/search",
            params={"q": q, "format": "json", "limit": 1, "addressdetails": 1},
            headers={"User-Agent": "TACNET/1.0 law-enforcement-search-coordinator"},
            timeout=8,
        )
        r.raise_for_status()
        data = r.json()
        if data:
            item = data[0]
            return {
                "lat": float(item["lat"]), "lng": float(item["lon"]),
                "display_name": item.get("display_name", q),
                "type": item.get("type", ""),
                "class": item.get("class", ""),
            }
    except requests.RequestException:
        pass
    raise HTTPException(404, "Address not found")


# ============= Cases =============
@api_router.post("/cases")
async def create_case(data: CaseIn, user: dict = Depends(get_current_user)):
    cid = str(uuid.uuid4())
    doc = {
        "id": cid,
        **data.model_dump(),
        "created_by": user["id"],
        "created_by_name": user["name"],
        "created_by_agency": user["agency"],
        "created_at": iso(now_utc()),
        "terminated_at": None,
        "terminated_by": None,
    }
    await db.cases.insert_one(doc)
    await audit_log(cid, user, "CASE_CREATED", f"Case '{data.title}' created")
    doc.pop("_id", None)
    return doc


@api_router.get("/cases")
async def list_cases(user: dict = Depends(get_current_user)):
    cases = await db.cases.find({}, {"_id": 0}).sort("created_at", -1).to_list(500)
    for c in cases:
        c["ping_count"] = await db.pings.count_documents({"case_id": c["id"]})
        c["searcher_count"] = await db.manual_searchers.count_documents({"case_id": c["id"]})
    return cases


@api_router.get("/cases/{case_id}")
async def get_case(case_id: str, user: dict = Depends(get_current_user)):
    c = await db.cases.find_one({"id": case_id}, {"_id": 0})
    if not c:
        raise HTTPException(404, "Case not found")
    return c


@api_router.patch("/cases/{case_id}")
async def update_case(case_id: str, data: CaseUpdate, user: dict = Depends(get_current_user)):
    updates = {k: v for k, v in data.model_dump().items() if v is not None}
    if not updates:
        return {"ok": True}
    await db.cases.update_one({"id": case_id}, {"$set": updates})
    await audit_log(case_id, user, "CASE_UPDATED", f"Updated: {', '.join(updates.keys())}")
    return await db.cases.find_one({"id": case_id}, {"_id": 0})


@api_router.delete("/cases/{case_id}")
async def delete_case(case_id: str, user: dict = Depends(get_current_user)):
    c = await db.cases.find_one({"id": case_id})
    if not c:
        raise HTTPException(404, "Case not found")
    # Cascade-delete all related data
    await db.pings.delete_many({"case_id": case_id})
    await db.manual_searchers.delete_many({"case_id": case_id})
    await db.drawings.delete_many({"case_id": case_id})
    await db.guest_tokens.delete_many({"case_id": case_id})
    await db.alerts.delete_many({"case_id": case_id})
    await db.audit.delete_many({"case_id": case_id})
    await db.cases.delete_one({"id": case_id})
    return {"ok": True}


@api_router.put("/cases/{case_id}/perimeter")
async def set_perimeter(case_id: str, data: PerimeterIn, user: dict = Depends(get_current_user)):
    await db.cases.update_one({"id": case_id}, {"$set": {
        "center_lat": data.center_lat,
        "center_lng": data.center_lng,
        "perimeter_radius_m": data.radius_m,
        "perimeter_address": data.address or "",
    }})
    detail = f"Perimeter set at {data.center_lat:.6f},{data.center_lng:.6f} r={int(data.radius_m)}m"
    if data.address:
        detail += f" — {data.address}"
    await audit_log(case_id, user, "PERIMETER_SET", detail)
    return await db.cases.find_one({"id": case_id}, {"_id": 0})


@api_router.post("/cases/{case_id}/terminate")
async def terminate_case(case_id: str, user: dict = Depends(get_current_user)):
    c = await db.cases.find_one({"id": case_id})
    if not c:
        raise HTTPException(404, "Case not found")
    if c.get("status") == "closed":
        raise HTTPException(400, "Case already terminated")
    await db.cases.update_one({"id": case_id}, {"$set": {
        "status": "closed",
        "terminated_at": iso(now_utc()),
        "terminated_by": user["name"],
        "terminated_by_agency": user["agency"],
    }})
    # Resolve any active officer-down alerts
    await db.alerts.update_many(
        {"case_id": case_id, "active": True},
        {"$set": {"active": False, "resolved_at": iso(now_utc()), "resolved_by": user["name"]}}
    )
    await audit_log(case_id, user, "SEARCH_TERMINATED",
                    f"Search terminated by {user['name']} ({user['agency']}). All state preserved.")
    return await db.cases.find_one({"id": case_id}, {"_id": 0})


# ============= GPS Pings =============
@api_router.post("/pings")
async def post_ping(data: PingIn, user: dict = Depends(get_current_user)):
    doc = {
        "id": str(uuid.uuid4()),
        "case_id": data.case_id,
        "user_id": user["id"],
        "user_name": user["name"],
        "agency": user["agency"],
        "lat": data.lat, "lng": data.lng,
        "accuracy": data.accuracy, "note": data.note,
        "ts": iso(now_utc()),
    }
    await db.pings.insert_one(doc)
    doc.pop("_id", None)
    return doc


@api_router.get("/cases/{case_id}/pings")
async def case_pings(case_id: str, user: dict = Depends(get_current_user)):
    return await db.pings.find({"case_id": case_id}, {"_id": 0}).sort("ts", 1).to_list(5000)


@api_router.get("/cases/{case_id}/searchers")
async def case_searchers(case_id: str, user: dict = Depends(get_current_user)):
    pipeline = [
        {"$match": {"case_id": case_id}},
        {"$sort": {"ts": -1}},
        {"$group": {"_id": "$user_id",
                    "user_id": {"$first": "$user_id"},
                    "user_name": {"$first": "$user_name"},
                    "agency": {"$first": "$agency"},
                    "lat": {"$first": "$lat"},
                    "lng": {"$first": "$lng"},
                    "ts": {"$first": "$ts"}}}
    ]
    out = []
    async for r in db.pings.aggregate(pipeline):
        r.pop("_id", None)
        out.append(r)
    return out


# ============= Manual Searchers (placed pins) =============
@api_router.post("/manual-searchers")
async def add_manual_searcher(data: ManualSearcherIn, user: dict = Depends(get_current_user)):
    cat = (data.category or "LE").upper()
    # auto-number per case+category if no name provided
    name = (data.name or "").strip()
    if not name:
        seq = await db.manual_searchers.count_documents({"case_id": data.case_id, "category": cat}) + 1
        name = f"{cat}-{seq}"
    agency = (data.agency or user.get("agency") or "—").strip()
    doc = {
        "id": str(uuid.uuid4()),
        "case_id": data.case_id,
        "name": name,
        "agency": agency,
        "category": cat,
        "lat": data.lat, "lng": data.lng,
        "placed_by": user["name"],
        "placed_by_agency": user["agency"],
        "placed_at": iso(now_utc()),
        "removed_at": None,
        "removed_by": None,
    }
    await db.manual_searchers.insert_one(doc)
    await audit_log(data.case_id, user, "SEARCHER_PLACED",
                    f"{cat} · {name} ({agency}) placed at {data.lat:.5f},{data.lng:.5f}")
    doc.pop("_id", None)
    return doc


@api_router.get("/cases/{case_id}/manual-searchers")
async def list_manual_searchers(case_id: str, user: dict = Depends(get_current_user)):
    return await db.manual_searchers.find(
        {"case_id": case_id, "removed_at": None}, {"_id": 0}
    ).sort("placed_at", 1).to_list(1000)


@api_router.delete("/manual-searchers/{ms_id}")
async def remove_manual_searcher(ms_id: str, user: dict = Depends(get_current_user)):
    ms = await db.manual_searchers.find_one({"id": ms_id})
    if not ms:
        raise HTTPException(404, "Not found")
    await db.manual_searchers.update_one({"id": ms_id}, {"$set": {
        "removed_at": iso(now_utc()),
        "removed_by": user["name"],
    }})
    await audit_log(ms["case_id"], user, "SEARCHER_REMOVED",
                    f"{ms['name']} ({ms['agency']}) removed from grid")
    return {"ok": True}


# ============= Drawings (Red pen freehand) =============
@api_router.post("/drawings")
async def add_drawing(data: DrawingIn, user: dict = Depends(get_current_user)):
    doc = {
        "id": str(uuid.uuid4()),
        "case_id": data.case_id,
        "points": data.points,
        "color": data.color or "#ff2a2a",
        "drawn_by": user["name"],
        "drawn_by_agency": user["agency"],
        "drawn_at": iso(now_utc()),
    }
    await db.drawings.insert_one(doc)
    await audit_log(data.case_id, user, "MAP_ANNOTATION",
                    f"Drawing added ({len(data.points)} points) by {user['name']}")
    doc.pop("_id", None)
    return doc


@api_router.get("/cases/{case_id}/drawings")
async def list_drawings(case_id: str, user: dict = Depends(get_current_user)):
    return await db.drawings.find({"case_id": case_id}, {"_id": 0}).sort("drawn_at", 1).to_list(1000)


@api_router.delete("/drawings/{d_id}")
async def delete_drawing(d_id: str, user: dict = Depends(get_current_user)):
    d = await db.drawings.find_one({"id": d_id})
    if not d:
        raise HTTPException(404, "Drawing not found")
    await db.drawings.delete_one({"id": d_id})
    await audit_log(d["case_id"], user, "MAP_ANNOTATION_REMOVED",
                    f"Drawing removed by {user['name']}")
    return {"ok": True}


@api_router.delete("/cases/{case_id}/drawings")
async def clear_drawings(case_id: str, user: dict = Depends(get_current_user)):
    n = await db.drawings.count_documents({"case_id": case_id})
    await db.drawings.delete_many({"case_id": case_id})
    await audit_log(case_id, user, "MAP_ANNOTATIONS_CLEARED",
                    f"All annotations cleared ({n} drawings)")
    return {"ok": True, "deleted": n}


# ============= Officer Down Alerts =============
@api_router.post("/officer-down")
async def officer_down(data: OfficerDownIn, user: dict = Depends(get_current_user)):
    doc = {
        "id": str(uuid.uuid4()),
        "case_id": data.case_id,
        "officer_id": user["id"],
        "officer_name": user["name"],
        "officer_agency": user["agency"],
        "badge": user.get("badge_number", ""),
        "lat": data.lat, "lng": data.lng,
        "note": data.note,
        "active": True,
        "triggered_at": iso(now_utc()),
        "resolved_at": None,
        "resolved_by": None,
    }
    await db.alerts.insert_one(doc)
    await audit_log(data.case_id, user, "OFFICER_DOWN",
                    f"!! OFFICER DOWN — {user['name']} ({user['agency']}) — requesting immediate assistance")
    doc.pop("_id", None)
    return doc


@api_router.get("/cases/{case_id}/alerts/active")
async def active_alerts(case_id: str, user: dict = Depends(get_current_user)):
    return await db.alerts.find(
        {"case_id": case_id, "active": True}, {"_id": 0}
    ).sort("triggered_at", -1).to_list(50)


@api_router.get("/cases/{case_id}/alerts")
async def all_alerts(case_id: str, user: dict = Depends(get_current_user)):
    return await db.alerts.find({"case_id": case_id}, {"_id": 0}).sort("triggered_at", -1).to_list(500)


@api_router.post("/alerts/{alert_id}/reset")
async def reset_alert(alert_id: str, user: dict = Depends(get_current_user)):
    a = await db.alerts.find_one({"id": alert_id})
    if not a:
        raise HTTPException(404, "Alert not found")
    await db.alerts.update_one({"id": alert_id}, {"$set": {
        "active": False,
        "resolved_at": iso(now_utc()),
        "resolved_by": user["name"],
    }})
    await audit_log(a["case_id"], user, "OFFICER_DOWN_RESET",
                    f"Officer-down alert for {a['officer_name']} reset by {user['name']}")
    return {"ok": True}


# ============= Guest Tokens =============
@api_router.post("/guest-tokens")
async def issue_guest_token(data: GuestTokenIn, user: dict = Depends(get_current_user)):
    tok = secrets.token_urlsafe(24)
    expires = now_utc() + timedelta(hours=max(1, min(168, data.hours_valid)))
    doc = {
        "id": str(uuid.uuid4()), "token": tok, "case_id": data.case_id,
        "agency": data.agency, "contact_name": data.contact_name,
        "contact_email": data.contact_email, "issued_by": user["name"],
        "issued_by_agency": user["agency"], "issued_at": iso(now_utc()),
        "expires_at": iso(expires), "revoked": False,
    }
    await db.guest_tokens.insert_one(doc)
    await audit_log(data.case_id, user, "GUEST_TOKEN_ISSUED",
                    f"Issued to {data.contact_name} ({data.agency})")
    doc.pop("_id", None)
    return doc


@api_router.get("/cases/{case_id}/guest-tokens")
async def list_guest_tokens(case_id: str, user: dict = Depends(get_current_user)):
    return await db.guest_tokens.find({"case_id": case_id}, {"_id": 0}).sort("issued_at", -1).to_list(200)


@api_router.post("/guest-tokens/{token_id}/revoke")
async def revoke_guest_token(token_id: str, user: dict = Depends(get_current_user)):
    t = await db.guest_tokens.find_one({"id": token_id})
    if not t:
        raise HTTPException(404, "Token not found")
    await db.guest_tokens.update_one({"id": token_id}, {"$set": {"revoked": True}})
    await audit_log(t["case_id"], user, "GUEST_TOKEN_REVOKED",
                    f"Token for {t['contact_name']} revoked")
    return {"ok": True}


# ============= Audit / Timeline =============
async def audit_log(case_id: str, user: dict, action: str, detail: str):
    await db.audit.insert_one({
        "id": str(uuid.uuid4()), "case_id": case_id,
        "user_id": user["id"], "user_name": user["name"],
        "agency": user["agency"], "action": action,
        "detail": detail, "ts": iso(now_utc()),
    })


@api_router.get("/cases/{case_id}/audit")
async def case_audit(case_id: str, user: dict = Depends(get_current_user)):
    return await db.audit.find({"case_id": case_id}, {"_id": 0}).sort("ts", -1).to_list(2000)


@api_router.get("/cases/{case_id}/timeline")
async def case_timeline(case_id: str, user: dict = Depends(get_current_user)):
    """Comprehensive recording — everything in chronological order."""
    events = []
    async for a in db.audit.find({"case_id": case_id}, {"_id": 0}):
        events.append({"ts": a["ts"], "kind": "AUDIT", "action": a["action"],
                       "actor": f"{a['user_name']} · {a['agency']}", "detail": a["detail"]})
    async for p in db.pings.find({"case_id": case_id}, {"_id": 0}):
        events.append({"ts": p["ts"], "kind": "GPS",
                       "actor": f"{p['user_name']} · {p['agency']}",
                       "detail": f"GPS ping at {p['lat']:.5f},{p['lng']:.5f}"})
    async for al in db.alerts.find({"case_id": case_id}, {"_id": 0}):
        events.append({"ts": al["triggered_at"], "kind": "ALERT",
                       "actor": f"{al['officer_name']} · {al['officer_agency']}",
                       "detail": "OFFICER DOWN triggered" + (f" — {al['note']}" if al.get('note') else "")})
        if al.get("resolved_at"):
            events.append({"ts": al["resolved_at"], "kind": "ALERT",
                           "actor": al.get("resolved_by", "—"),
                           "detail": "Officer-down alert reset"})
    events.sort(key=lambda e: e["ts"])
    return events


# ============= Court-Ready PDF Report =============
class TacnetHeader:
    """Brilliant colorful TACNET branded header drawn as a flowable."""
    pass

def draw_tacnet_header(c, doc_meta):
    """Draws a colorful TACNET masthead banner."""
    d = Drawing(7.3*inch, 1.05*inch)
    # Dark navy background bar
    d.add(Rect(0, 0, 7.3*inch, 1.05*inch, fillColor=colors.HexColor('#0a1a2f'),
               strokeColor=colors.HexColor('#ff2a2a'), strokeWidth=2))
    # Red accent stripe
    d.add(Rect(0, 0.92*inch, 7.3*inch, 0.04*inch, fillColor=colors.HexColor('#ff2a2a'), strokeWidth=0))
    d.add(Rect(0, 0.06*inch, 7.3*inch, 0.04*inch, fillColor=colors.HexColor('#ff2a2a'), strokeWidth=0))
    # Gold TACNET text
    s = String(0.3*inch, 0.55*inch, "TACNET",
               fillColor=colors.HexColor('#fde08a'), fontName="Helvetica-Bold", fontSize=32)
    d.add(s)
    # Subtitle
    sub = String(0.3*inch, 0.32*inch,
                 "FEDERAL · STATE · LOCAL MULTI-AGENCY TASK FORCE SEARCH NETWORK",
                 fillColor=colors.white, fontName="Helvetica", fontSize=8)
    d.add(sub)
    # Shield emblem (gold/navy lozenge)
    shield_x = 6.5*inch
    d.add(Polygon(points=[shield_x, 0.85*inch,
                          shield_x+0.4*inch, 0.85*inch,
                          shield_x+0.45*inch, 0.55*inch,
                          shield_x+0.2*inch, 0.18*inch,
                          shield_x-0.05*inch, 0.55*inch],
                  fillColor=colors.HexColor('#fde08a'),
                  strokeColor=colors.HexColor('#0a1a2f'), strokeWidth=1.2))
    d.add(String(shield_x+0.07*inch, 0.5*inch, "SAR",
                 fillColor=colors.HexColor('#0a1a2f'),
                 fontName="Helvetica-Bold", fontSize=10))
    # Right-side meta
    d.add(String(5.0*inch, 0.55*inch, doc_meta.get("doc_id", ""),
                 fillColor=colors.HexColor('#fde08a'),
                 fontName="Courier", fontSize=8))
    d.add(String(5.0*inch, 0.40*inch, doc_meta.get("generated", ""),
                 fillColor=colors.white, fontName="Courier", fontSize=7))
    d.add(String(5.0*inch, 0.27*inch, "COURT-READY · CHAIN-OF-CUSTODY",
                 fillColor=colors.HexColor('#6df08a'),
                 fontName="Helvetica-Bold", fontSize=7))
    return d


async def build_report_pdf(case_id: str, user: dict) -> tuple:
    c = await db.cases.find_one({"id": case_id}, {"_id": 0})
    if not c:
        raise HTTPException(404, "Case not found")
    pings = await db.pings.find({"case_id": case_id}, {"_id": 0}).sort("ts", 1).to_list(10000)
    audit = await db.audit.find({"case_id": case_id}, {"_id": 0}).sort("ts", 1).to_list(5000)
    tokens = await db.guest_tokens.find({"case_id": case_id}, {"_id": 0}).sort("issued_at", 1).to_list(500)
    alerts = await db.alerts.find({"case_id": case_id}, {"_id": 0}).sort("triggered_at", 1).to_list(500)
    manual = await db.manual_searchers.find({"case_id": case_id}, {"_id": 0}).sort("placed_at", 1).to_list(2000)
    drawings = await db.drawings.find({"case_id": case_id}, {"_id": 0}).sort("drawn_at", 1).to_list(2000)

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=LETTER,
                            leftMargin=0.5*inch, rightMargin=0.5*inch,
                            topMargin=0.5*inch, bottomMargin=0.5*inch)
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle('h1', parent=styles['Heading1'],
                        textColor=colors.HexColor('#0a1a2f'), fontSize=16,
                        spaceAfter=10)
    h2 = ParagraphStyle('h2', parent=styles['Heading2'],
                        textColor=colors.white, fontSize=12,
                        backColor=colors.HexColor('#1a3a5f'),
                        borderPadding=6, spaceBefore=12, spaceAfter=8,
                        leftIndent=0, alignment=TA_LEFT)
    body = ParagraphStyle('body', parent=styles['BodyText'], fontSize=9, leading=12)
    small = ParagraphStyle('s', parent=styles['BodyText'], fontSize=8, textColor=colors.grey)

    doc_id = f"TACNET-{c['case_number']}-{uuid.uuid4().hex[:6].upper()}"
    story = []
    story.append(draw_tacnet_header(None, {"doc_id": doc_id, "generated": iso(now_utc())[:19] + "Z"}))
    story.append(Spacer(1, 14))

    story.append(Paragraph(f"OFFICIAL OPERATIONAL REPORT — CASE #{c['case_number']}", h1))
    story.append(Paragraph(f"<b>Generated:</b> {iso(now_utc())} &nbsp;&nbsp; <b>By:</b> {user['name']} ({user['agency']}, badge {user.get('badge_number','—')})", small))
    story.append(Spacer(1, 10))

    # Case info table
    meta = [
        ["CASE NUMBER", c['case_number'], "STATUS", c['status'].upper()],
        ["TITLE", c['title'], "OPENED", c['created_at'][:19].replace('T',' ')],
        ["LOCATION", c['location'], "LEAD AGENCY", c['created_by_agency']],
        ["PERIMETER", f"{c.get('perimeter_radius_m', 500)} m radius", "LEAD OFFICER", c['created_by_name']],
        ["CENTER LAT/LNG", f"{c['center_lat']:.6f}, {c['center_lng']:.6f}", "TERMINATED", c.get('terminated_at') or '—'],
    ]
    t = Table(meta, colWidths=[1.1*inch, 2.7*inch, 1.0*inch, 2.6*inch])
    t.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (0,-1), colors.HexColor('#fde08a')),
        ('BACKGROUND', (2,0), (2,-1), colors.HexColor('#fde08a')),
        ('TEXTCOLOR', (0,0), (0,-1), colors.HexColor('#0a1a2f')),
        ('TEXTCOLOR', (2,0), (2,-1), colors.HexColor('#0a1a2f')),
        ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
        ('FONTNAME', (2,0), (2,-1), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#0a1a2f')),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('PADDING', (0,0), (-1,-1), 5),
        ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ]))
    story.append(t)
    story.append(Spacer(1, 10))

    # Description
    story.append(Paragraph("<b>NARRATIVE</b>", body))
    desc_box = Table([[Paragraph(c['description'], body)]], colWidths=[7.4*inch])
    desc_box.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#f4f7fb')),
        ('BOX', (0,0), (-1,-1), 0.5, colors.HexColor('#1a3a5f')),
        ('PADDING', (0,0), (-1,-1), 8),
    ]))
    story.append(desc_box)

    # Officer-down alerts (high visibility)
    if alerts:
        story.append(Paragraph("OFFICER-DOWN ALERTS", h2))
        rows = [["Triggered", "Officer", "Agency", "Resolved", "Detail"]]
        for a in alerts:
            rows.append([a['triggered_at'][:19], a['officer_name'], a['officer_agency'],
                         a.get('resolved_at','— ACTIVE —')[:19] if a.get('resolved_at') else "— ACTIVE —",
                         a.get('note') or "—"])
        at = Table(rows, colWidths=[1.3*inch, 1.3*inch, 1.2*inch, 1.5*inch, 2.1*inch])
        at.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#ff2a2a')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('GRID', (0,0), (-1,-1), 0.3, colors.grey),
            ('FONTSIZE', (0,0), (-1,-1), 8),
            ('BACKGROUND', (0,1), (-1,-1), colors.HexColor('#ffe6e6')),
        ]))
        story.append(at)

    # Audit / Chain of Custody
    story.append(Paragraph("CHAIN OF CUSTODY", h2))
    rows = [["Timestamp", "Officer", "Agency", "Action", "Detail"]]
    for a in audit:
        rows.append([a['ts'][:19], a['user_name'], a['agency'], a['action'], (a['detail'] or "")[:90]])
    if len(rows) == 1:
        rows.append(["—","—","—","—","No events"])
    at = Table(rows, colWidths=[1.3*inch, 1.2*inch, 1.0*inch, 1.4*inch, 2.5*inch], repeatRows=1)
    at.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1a3a5f')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 0.3, colors.grey),
        ('FONTSIZE', (0,0), (-1,-1), 7.5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f4f7fb')]),
    ]))
    story.append(at)

    # GPS Track
    story.append(Paragraph(f"GPS SEARCH TRACK — {len(pings)} ENTRIES", h2))
    rows = [["Timestamp", "Officer", "Agency", "Lat", "Lng", "Acc(m)"]]
    for p in pings[:300]:
        rows.append([p['ts'][:19], p['user_name'], p['agency'],
                     f"{p['lat']:.6f}", f"{p['lng']:.6f}",
                     f"{p.get('accuracy') or 0:.1f}"])
    if len(rows) == 1:
        rows.append(["—","—","—","—","—","—"])
    pt = Table(rows, colWidths=[1.3*inch, 1.3*inch, 1.0*inch, 1.1*inch, 1.1*inch, 0.6*inch], repeatRows=1)
    pt.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1a3a5f')),
        ('TEXTCOLOR', (0,0), (-1,0), colors.white),
        ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
        ('GRID', (0,0), (-1,-1), 0.3, colors.grey),
        ('FONTSIZE', (0,0), (-1,-1), 7.5),
        ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f4f7fb')]),
    ]))
    story.append(pt)

    # Manually placed searchers
    if manual:
        story.append(Paragraph(f"DEPLOYED SEARCHERS — {len(manual)} POSITIONS", h2))
        rows = [["Placed At", "Name", "Agency", "Lat", "Lng", "Placed By"]]
        for m in manual:
            rows.append([m['placed_at'][:19], m['name'], m['agency'],
                         f"{m['lat']:.6f}", f"{m['lng']:.6f}", m['placed_by']])
        mt = Table(rows, colWidths=[1.3*inch, 1.3*inch, 1.0*inch, 1.0*inch, 1.0*inch, 1.4*inch], repeatRows=1)
        mt.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1a3a5f')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('GRID', (0,0), (-1,-1), 0.3, colors.grey),
            ('FONTSIZE', (0,0), (-1,-1), 7.5),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f4f7fb')]),
        ]))
        story.append(mt)

    # Drawings
    if drawings:
        story.append(Paragraph(f"MAP ANNOTATIONS — {len(drawings)} OVERLAYS", h2))
        rows = [["Drawn At", "By", "Agency", "Points"]]
        for d in drawings:
            rows.append([d['drawn_at'][:19], d['drawn_by'], d['drawn_by_agency'], str(len(d['points']))])
        dt = Table(rows, colWidths=[1.6*inch, 1.5*inch, 1.5*inch, 2.4*inch], repeatRows=1)
        dt.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1a3a5f')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('GRID', (0,0), (-1,-1), 0.3, colors.grey),
            ('FONTSIZE', (0,0), (-1,-1), 7.5),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f4f7fb')]),
        ]))
        story.append(dt)

    # Outside-agency tokens
    if tokens:
        story.append(Paragraph("OUTSIDE-AGENCY ACCESS TOKENS", h2))
        rows = [["Issued", "Contact", "Agency", "Email", "Expires", "Revoked"]]
        for tk in tokens:
            rows.append([tk['issued_at'][:19], tk['contact_name'], tk['agency'],
                         tk['contact_email'], tk['expires_at'][:19], "YES" if tk['revoked'] else "no"])
        tt = Table(rows, colWidths=[1.3*inch, 1.2*inch, 1.0*inch, 1.7*inch, 1.3*inch, 0.7*inch], repeatRows=1)
        tt.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#1a3a5f')),
            ('TEXTCOLOR', (0,0), (-1,0), colors.white),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('GRID', (0,0), (-1,-1), 0.3, colors.grey),
            ('FONTSIZE', (0,0), (-1,-1), 7.5),
            ('ROWBACKGROUNDS', (0,1), (-1,-1), [colors.white, colors.HexColor('#f4f7fb')]),
        ]))
        story.append(tt)

    story.append(Spacer(1, 12))
    sig = Table([
        ["Report ID:", doc_id, "Generated By:", f"{user['name']} ({user['agency']})"],
        ["Generated At:", iso(now_utc()), "Verification:", f"Document SHA suffix {uuid.uuid4().hex[:12]}"],
    ], colWidths=[1.1*inch, 2.5*inch, 1.2*inch, 2.6*inch])
    sig.setStyle(TableStyle([
        ('BACKGROUND', (0,0), (-1,-1), colors.HexColor('#0a1a2f')),
        ('TEXTCOLOR', (0,0), (-1,-1), colors.white),
        ('FONTSIZE', (0,0), (-1,-1), 8),
        ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
        ('FONTNAME', (2,0), (2,-1), 'Helvetica-Bold'),
        ('TEXTCOLOR', (0,0), (0,-1), colors.HexColor('#fde08a')),
        ('TEXTCOLOR', (2,0), (2,-1), colors.HexColor('#fde08a')),
        ('PADDING', (0,0), (-1,-1), 6),
    ]))
    story.append(sig)
    story.append(Spacer(1, 6))
    story.append(Paragraph(
        "This document is machine-generated by TACNET and constitutes an official record of the search "
        "operation. It is suitable for chain-of-custody review and court submission. Any modification "
        "of this document outside the TACNET system invalidates its evidentiary status.",
        small))

    doc.build(story)
    buf.seek(0)
    await audit_log(case_id, user, "REPORT_GENERATED", f"Court-ready PDF report generated ({doc_id})")
    return buf, c, doc_id


@api_router.get("/cases/{case_id}/report")
async def case_report(case_id: str, user: dict = Depends(get_current_user)):
    buf, c, _ = await build_report_pdf(case_id, user)
    return StreamingResponse(buf, media_type="application/pdf",
                             headers={"Content-Disposition": f'attachment; filename="TACNET_{c["case_number"]}.pdf"'})


@api_router.post("/cases/{case_id}/report/email")
async def case_report_email(case_id: str, data: EmailReportIn, user: dict = Depends(get_current_user)):
    """Generates the PDF, returns a mailto:-style payload so the operating
    officer's mail client opens with recipients/subject/body pre-filled.
    The PDF must be downloaded and attached by the officer (chain-of-custody requirement)."""
    c = await db.cases.find_one({"id": case_id}, {"_id": 0})
    if not c:
        raise HTTPException(404, "Case not found")
    recipients = ",".join(data.recipients)
    subject = f"TACNET Operational Report — Case #{c['case_number']} ({c['title']})"
    body = (
        f"TACNET — Federal · State · Local Multi-Agency Task Force Search Network\n"
        f"-----------------------------------------------------------------------\n\n"
        f"Case Number : {c['case_number']}\n"
        f"Title       : {c['title']}\n"
        f"Location    : {c['location']}\n"
        f"Status      : {c['status'].upper()}\n"
        f"Lead Agency : {c['created_by_agency']} ({c['created_by_name']})\n\n"
        f"The official court-ready PDF report has been generated and is attached "
        f"to this email. Verify the document ID on the masthead before forwarding.\n\n"
        f"Sent by: {user['name']} — {user['agency']} (badge {user.get('badge_number','—')})\n"
        f"Generated: {iso(now_utc())}\n"
    )
    mailto = (
        f"mailto:{urllib.parse.quote(recipients)}"
        f"?subject={urllib.parse.quote(subject)}"
        f"&body={urllib.parse.quote(body)}"
    )
    await audit_log(case_id, user, "REPORT_EMAILED",
                    f"Report email prepared for {recipients}")
    return {"mailto": mailto, "recipients": data.recipients}


# ============= Dashboard stats =============
@api_router.get("/stats")
async def stats(user: dict = Depends(get_current_user)):
    active = await db.cases.count_documents({"status": "active"})
    closed = await db.cases.count_documents({"status": "closed"})
    deployed = await db.manual_searchers.count_documents({"removed_at": None})
    alerts_active = await db.alerts.count_documents({"active": True})
    return {"active_cases": active, "closed_cases": closed,
            "deployed_searchers": deployed, "active_alerts": alerts_active}


@api_router.get("/")
async def root():
    return {"service": "TACNET", "ok": True}


# ============= App config / startup =============
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_origin_regex=".*",
    allow_methods=["*"],
    allow_headers=["*"],
)


logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


@app.on_event("startup")
async def startup():
    await db.users.create_index("email", unique=True)
    await db.cases.create_index("id", unique=True)
    await db.pings.create_index([("case_id", 1), ("ts", -1)])
    await db.guest_tokens.create_index("token", unique=True)
    await db.manual_searchers.create_index([("case_id", 1), ("placed_at", -1)])
    await db.alerts.create_index([("case_id", 1), ("active", 1)])
    # No pre-seeded users. Officers register their own accounts on first launch.


@app.on_event("shutdown")
async def shutdown():
    client.close()
